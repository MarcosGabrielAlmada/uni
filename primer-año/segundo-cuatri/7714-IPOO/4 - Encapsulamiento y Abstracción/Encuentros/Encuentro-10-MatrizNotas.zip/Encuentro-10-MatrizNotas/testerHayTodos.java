class testerHayTodos{

public static void main (String a[]){

   NotasParciales notas = new NotasParciales (3,4);
   notas.establecerNota(100,0,0);
   notas.establecerNota(90,0,1);
   notas.establecerNota(70,0,2);
   notas.establecerNota(80,0,3);  
   
   notas.establecerNota(60,1,0);
   notas.establecerNota(50,1,1);
   notas.establecerNota(70,1,2);
   notas.establecerNota(55,1,3); 
   
   notas.establecerNota(80,2,0);
   notas.establecerNota(90,2,1);
   notas.establecerNota(65,2,2);
   notas.establecerNota(45,2,3); 
   
   mostrarMatriz(notas);
   System.out.println ("Verificación del método que decide si hay un alumno que desaprobó todos los parciales");
   System.out.println ("Espero false y retorna "+notas.hayTodosDesaprobados());

   notas.establecerNota(40,1,0);
   notas.establecerNota(50,1,1);
   notas.establecerNota(50,1,2);
   notas.establecerNota(55,1,3);  

   mostrarMatriz(notas);
   System.out.println ("Verificación del método que decide si hay un alumno que desaprobó todos los parciales");
   System.out.println ("Espero true y retorna "+notas.hayTodosDesaprobados());   
   
}
public static void mostrarMatriz(NotasParciales notas){
  for (int i = 0; i < notas.cantFilas(); i++){
    for (int j = 0 ; j < notas.cantColumnas (); j++)
      System.out.print (notas.obtenerNota(i,j)+" ");
    System.out.println (" ");
}
}
}