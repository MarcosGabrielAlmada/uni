class NotasParciales {
//Atributos
private static final int minimo_aprobacion = 60;
private int [][] np;

//Constructor
public NotasParciales (int nFil,int nCol){
//Requiere nFil y nCol mayor a 0
  np = new int [nFil][nCol];
}
//Comandos
public void establecerNota(int n, int f, int c){
/*Modifica la nota que corresponde a la fila f y columna c, 
 * si n está en el rango 0-100. Requiere f,c válidos. */
  if (n >=0 && n <=100)
    np[f][c] = n;
}
//Consultas
public int obtenerNota(int f, int c){
//Requiere f,c válidos. 
  return np[f][c];
}
public int cantFilas(){
  return np.length; 
}
public int cantColumnas(){
  return np[0].length;
}
public int cantAprobados(){
//Computa la cantidad de notas mayores al mínimo de aprobación.
  int contador = 0;
  for (int f=0; f < cantFilas(); f++)
    for (int c=0; c < cantColumnas(); c++)
       if (np[f][c] >= minimo_aprobacion)
          contador++;
  return contador;  
}
public int cantAprobadosFila(int f){
/*Computa la cantidad de notas mayores al mínimo de aprobación 
 * para el alumno que corresponde a la fila f. Requiere f válida*/
   int contador = 0;
   for (int c=0; c < cantColumnas(); c++)
      if (np[f][c] >= minimo_aprobacion)
        contador++;
   return contador;
}
public int cantAprobadosColumna(int c){
/*Computa la cantidad de notas mayores al mínimo de aprobación 
 * para el parcial que corresponde a la columna c. Requiere c válida. */
   int contador = 0;
   for (int f=0; f < cantFilas(); f++)
      if (np[f][c] >= minimo_aprobacion)
        contador++;
   return contador;
}
public boolean hayTodosDesaprobados(){
//Retorna true si hay al menos un alumno que desaprobó todos los parciales.
/* 
 *   para cada fila y mientras no encontremos un alumno que desaprobó todos los parciales
 *      para cada columna y mientras no encuentre un parcial aprobado
           si el alumno aprobó el parcial la fila no verifica la propiedad
   */
  boolean hayAlumno=false;
  boolean unAprobado;
  for (int f=0; f < cantFilas() && !hayAlumno ; f++){
    unAprobado=false;
    for (int c=0; c < cantColumnas() && !unAprobado ; c++)
      if(np[f][c] >= minimo_aprobacion)
        unAprobado = true;
    hayAlumno = !unAprobado;    
   }
  return hayAlumno;      
} 

public boolean dosConsecutivosDes(int f){
/*Retorna true si el alumno que corresponde a la fila f 
 *desaprobó dos parciales consecutivos. */
  boolean hayDos = false;
  for (int c = 0; c < cantColumnas() - 1; f++){
    if (np[f][c] < minimo_aprobacion && np[f][c + 1] < minimo_aprobacion)
      hayDos = true;
  }
  return hayDos;
}

/*
public boolean alMenosNParcialesAp(int p, int n){
  /* Retorna true si el alumno p aprobó al menos n parciales.*/
/*  boolean hay = false;
  for (int i = 0; i < cantColumnas(); i++)
    
  return hay;
}
*/
}
