
import java.util.Comparator;

public class Principal {

	public static void main(String[] args) {
		String s1, s2, s3;
		
		s1 = "AAAAAAA";
		s2 = "AAAAAAA";
		s3 = "CCCCCCC";
		
		int resultado = s1.compareTo(s3);
		System.out.println("resultado: " + resultado);
		
		Float f1, f2, f3;
		f1 = 12.0f;
		f2 = 12.0f;
		f3 = 94.0f;
		
		int resultado2 = f3.compareTo(f2);
		System.out.println("resultado2: " + resultado2);
		
		if ( resultado2 == 0 ) System.out.println("Son iguales");
		else if ( resultado2 > 0 ) System.out.println("El primero es más grande que el segundo");
		else if ( resultado2 < 0 )System.out.println("El primero es más chico que el segundo");
		
		Comparator<String> compString = new ComparadorPorDefecto<String>();
		System.out.println("Comparo Pedro con Pablo: " + compString.compare("Pedro", "Pablo"));
		
		Persona p1 = new Persona("Juan", 1.80f, 1e6f);
		Persona p2 = new Persona("Tito", 1.60f, 1e9f);
		Comparator<Persona> comp = new ComparadorPorDefecto<Persona>();
		int r = comp.compare(p1, p2);
		System.out.println("r: " + r);
		
		
		Comparator<Persona> cpd = new ComparadorPersonasPorDinero();
		System.out.println("juan y tito comparados por dinero: " + cpd.compare(p1, p2));
	}

}
