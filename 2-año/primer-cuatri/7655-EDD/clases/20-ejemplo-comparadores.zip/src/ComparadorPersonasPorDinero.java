
import java.util.Comparator;

public class ComparadorPersonasPorDinero implements Comparator<Persona> {

	@Override
	public int compare(Persona o1, Persona o2) {
		if ( o1.getDinero() == o2.getDinero() ) return 0;
		else if ( o1.getDinero() < o2.getDinero() ) return -1;
		else return 1;
	}

}
