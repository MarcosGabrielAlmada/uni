
public class Persona implements Comparable<Persona> {
     private String nombre;
     private float altura;
     private float dinero;

     public Persona(String nombre, float altura, float dinero)  {
        this.nombre = nombre;      this.altura = altura;  this.dinero = dinero;
     }
 
     public int compareTo(Persona p) {
         if (altura == p.getAltura()) return 0;
         else if (altura < p.getAltura()) return -1;
         else return 1;
     }

     public float getAltura() { return altura; }
     public String getNombre( ) { return nombre; }
     public float getDinero() { return dinero; }
}
