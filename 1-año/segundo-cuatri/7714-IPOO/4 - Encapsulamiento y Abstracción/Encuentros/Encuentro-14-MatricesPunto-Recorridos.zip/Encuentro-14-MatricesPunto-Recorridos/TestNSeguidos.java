
class TestNSeguidos {
public static void main(String[] args) {    
    
 MatrizPuntos unaMatriz;
 unaMatriz = genMatrizPuntos() ;
 System.out.println("Muestra la Matriz  ");
 mostrarMatrizPuntos(unaMatriz) ;
 
 System.out.println("fila = 0 n = 2, hayNSeguidos debería mostrar true, muestra "+unaMatriz.hayNSeguidos (0,2));
 System.out.println("fila = 0 n = 3, hayNSeguidoss debería mostrar false, muestra "+unaMatriz.hayNSeguidos (0,3));
 System.out.println("fila = 1 n = 3, hayNSeguidos debería mostrar true, muestra "+unaMatriz.hayNSeguidos (1,3));
 System.out.println("fila = 1 n = 4, hayNSeguidoss debería mostrar false, muestra "+unaMatriz.hayNSeguidos (1,4));
 System.out.println("fila = 2 n = 2, hayNSeguidos debería mostrar true, muestra "+unaMatriz.hayNSeguidos (2,2));
 System.out.println("fila = 2 n = 3, hayNSeguidoss debería mostrar false, muestra "+unaMatriz.hayNSeguidos (2,3));
}
public static MatrizPuntos genMatrizPuntos() {
  MatrizPuntos e= new 	MatrizPuntos(3,6);
  e.establecerPunto (0,0,new Punto (2,2)) ;
  e.establecerPunto (0,1,new Punto (0,1)) ;
  e.establecerPunto (0,2,new Punto (2,1)) ;
  e.establecerPunto (0,3,new Punto (0,3)) ;  
  e.establecerPunto (0,4,new Punto (0,1)) ;
  e.establecerPunto (0,5,new Punto (4,5)) ;
  
  e.establecerPunto (1,0,new Punto (2,2)) ;
  e.establecerPunto (1,1,new Punto (2,1)) ;
  e.establecerPunto (1,2,new Punto (0,1)) ;
  e.establecerPunto (1,3,new Punto (0,3)) ;  
  e.establecerPunto (1,4,new Punto (0,1)) ;
  e.establecerPunto (1,5,new Punto (3,5)) ;
  
  e.establecerPunto (2,0,null) ;
  e.establecerPunto (2,1,new Punto (1,1)) ;
  e.establecerPunto (2,2,new Punto (0,0)) ;
  e.establecerPunto (2,3,null) ;
  e.establecerPunto (2,4,new Punto (0,3)) ;  
  e.establecerPunto (2,5,new Punto (0,5)) ;  
  
  return e;
}

public static void    mostrarMatrizPuntos (MatrizPuntos e){
  for (int i=0;i< e.cantFilas();i++){
     for (int j=0;j< e.cantColumnas();j++)
       if (e.obtenerPunto(i,j) != null)
        System.out.print(" "+e.obtenerPunto(i,j).toString() );
       else
        System.out.print ( "   NULL   ");
     System.out.println();
    }
 }
}